<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/**
 * @OA\Info(
 *   version="1.0",
 *
 *   title=" API Documentation",
 *   descrption="API documentation for version 1.0 endpoints.",
 *
 *   @OA\Contact(
 *     email="test@mail.com"
 *   ),
 * )
 */

Route::prefix('auth')->as('auth.')->group(base_path('routes/groups/auth.php'));

Route::middleware(['auth:sanctum'])->get('/user', function (Request $request) {
    return $request->user();
});
