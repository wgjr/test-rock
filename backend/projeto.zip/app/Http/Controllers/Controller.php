<?php

namespace App\Http\Controllers;
use OpenApi\Annotations as OA;

/**
 * @OA\Info(
 *     version="0.1",
 *     title="API Documentation"
 * )
 */
abstract class Controller
{

}
